#include <stdio.h>
#pragma once

void make_sound(char sound[], int count);