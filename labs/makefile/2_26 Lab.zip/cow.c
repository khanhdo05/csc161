#include <stdio.h>
#include "chicken.h"
#include "util.h"

// Make a chicken sound a specified number of times
void cow_sound(int count) {
  make_sound("moo", count);
}
