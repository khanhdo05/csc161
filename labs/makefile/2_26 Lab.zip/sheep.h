#pragma once

void sheep_sound(int count);