#include <stdio.h>
#include "sheep.h"
#include "util.h"

// Make a chicken sound a specified number of times
void sheep_sound(int count) {
  make_sound("baah", count);
}
