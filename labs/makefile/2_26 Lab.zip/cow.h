#pragma once
void cow_sound(int count);