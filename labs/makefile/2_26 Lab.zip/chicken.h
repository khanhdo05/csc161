#pragma once
void chicken_sound(int count);